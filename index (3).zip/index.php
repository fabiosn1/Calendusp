<!DOCTYPE html>

<html>
    <head> </head>
	<body>
		<?php 

			$day = array();
			$month = array();
			$name = array();
			$j = 0;
					    
		    # array containing months of the year
		    $months = array(
				"janeiro",
				"fevereiro",
				"março",
				"abril",
			    "maio",
				"junho",
				"agosto",
				"setembro",
				"outubro",
				"novembro",
				"dezembro",
			);
		    
		    # creates and loads simple html dom parser

		    include('simple_html_dom.php');
			
			
			$html = file_get_html('https://uspdigital.usp.br/jupiterweb/jupCalendario2014.jsp');
			
			$tdelements = $html->find('td'); 
			
			# echo 'count: '. count($tdelements).'<br><br>';

			for($i = 0; $i < count($tdelements)	; $i++){
				if(($monthNumber = isMonth($tdelements[$i]->plaintext)) != -1){
	#			$echo 'Month Number: '.$monthNumber.'<br>';	
					while(isMonth($tdelements[$i]) == -1){
						$day[$j] = $tdelements[$i+1]->plaintext;
						$month[$j] = $monthNumber+1; 
				    	$name[$j] = $tdelements[$i+2]->plaintext;
						$i = $i + 2;
						$j++;
					}	
				}
			}
			
			for($i = 0; $i <= $j; $i++){
				echo 'day: '.$day[$i].'  month: '.$month[$i].' name: '.$name[$i].'<br>'; 
				
			}
						
			function isMonth($value){
					
				# puts $value to lower case and checks whether it's a month
				global $months;
				
			    $value = strtolower($value);

				for($j = 0; $j < count($months) && strlen($value) != 0; $j++){
					
					if(strpos($value, $months[$j]) !== FALSE){
						
				        return $j;
					}
				}
				return -1;
			} 
		    echo 'Henry viadinho! o||o';
			
		?>
	</body>
</html>