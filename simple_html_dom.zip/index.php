<!DOCTYPE html>

<html>
    <head> </head>
	<body>
		<?php 

			$days = array();
			$names = array();
			$j = 0;
					    
		    # array containing months of the year
		    $months = array(
				1 => "janeiro",
				2 => "fevereiro",
				3 => "março",
				4 => "abril",
			    5 => "maio",
				6 => "junho",
				7 => "agosto",
				8 => "setembro",
				9 => "outubro",
				10 => "novembro",
				11 => "dezembro",
			);
		    
		    # creates and loads simple html dom parser

		    include('simple_html_dom.php');
			
			$html = file_get_html('https://uspdigital.usp.br/jupiterweb/jupCalendario2014.jsp');
			
			$tdelements = $html->find('td'); 
			
	 			echo 'count: '. count($tdelements);
			for($i = 0; $i < count($tdelements); $i++){
					
				# loops through all 'td' elements, which are found and placed in $tdelements
				
				echo  'element: '.$tdelements[$i]->plaintext. '<br>';

			    	    
					   while(isMonth($tdelements[$i+2]) === TRUE){
	    			      # places the next element in $days and the 2-next element in $names 
				          echo 'while<br>';
					   	  $days[$j] = $tdelements[$i+1]->plaintext; 
						  $names[$j] = $tdelements[$i+2]->plaintext;
						  echo 'while: '.$tdelements[$i+1]->plaintext.' + '.$tdelements[$i+2]->plaintext;
				          $i = $i + 2;	
					   }
				
			}
			
			function isMonth($value){
					
				# puts $value to lower case and checks whether it's a month
				
			    $value = strtolower($value);
				for($j = 0; $j < count($months); $j++){
					if(strpos($value, $months[$j]) !== FALSE){
						return TRUE;
					}
					return FALSE;
				}
			} 
		    echo 'Henry viadinho! o||o';
			
		?>
	</body>
</html>